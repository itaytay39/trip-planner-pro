import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Box,
  Typography,
  Card,
  CardContent,
  IconButton,
  Fab,
  useTheme,
  alpha,
  useMediaQuery,
  Chip,
} from '@mui/material';
import {
  Home as HomeIcon,
  Map as MapIcon,
  AccountBalanceWallet as WalletIcon,
  Person as PersonIcon,
  Route as RouteIcon,
  LocationOn,
  Flight,
  Favorite,
  Share,
  Add,
  Notifications,
  Search,
  AttachMoney,
  CheckCircleOutline as CheckCircleOutlineIcon, // הוספנו אייקון
} from '@mui/icons-material';

// Import Components
import BudgetTracker from './components/BudgetTracker';
import RouteManager from './components/RouteManager';
import UserProfile from './components/UserProfile';
import GoogleMapComponent from './components/GoogleMap';
import PlaceSearch from './components/PlaceSearch';
import Checklist from './components/Checklist';

// Import Firebase and Types
import { db } from './firebase';
import { collection, onSnapshot, doc } from 'firebase/firestore';
import { Trip, User } from './types';

// =================================================================
// רכיבי עזר
// =================================================================

const Header = ({ user }: { user: User }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Box
      sx={{
        position: 'sticky',
        top: 0,
        background: `linear-gradient(135deg, ${alpha(
          theme.palette.background.paper,
          0.95
        )} 0%, ${alpha(theme.palette.background.paper, 0.8)} 100%)`,
        backdropFilter: 'blur(20px)',
        borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
        padding: isMobile ? '12px 16px' : '16px 20px',
        zIndex: 100,
        boxShadow: '0 2px 20px rgba(0,0,0,0.05)',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <Box>
          <Typography
            variant={isMobile ? 'h6' : 'h5'}
            sx={{
              fontWeight: 800,
              background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            שלום, {user.name.split(' ')[0]} 👋
          </Typography>
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ fontWeight: 500, fontSize: isMobile ? '12px' : '14px' }}
          >
            בואו נתכנן את הטיול הבא שלך
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <IconButton
            size={isMobile ? 'small' : 'medium'}
            sx={{
              background: alpha(theme.palette.primary.main, 0.1),
              '&:hover': { background: alpha(theme.palette.primary.main, 0.2) },
            }}
          >
            <Search fontSize={isMobile ? 'small' : 'medium'} />
          </IconButton>
          <IconButton
            size={isMobile ? 'small' : 'medium'}
            sx={{
              background: alpha(theme.palette.primary.main, 0.1),
              '&:hover': { background: alpha(theme.palette.primary.main, 0.2) },
            }}
          >
            <Notifications fontSize={isMobile ? 'small' : 'medium'} />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};

const TripCard = ({ trip, index }: { trip: Trip; index: number }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.6, ease: 'easeOut' }}
      whileHover={{ y: -5 }}
      whileTap={{ scale: 0.98 }}
    >
      <Card
        sx={{
          borderRadius: isMobile ? '20px' : '24px',
          overflow: 'hidden',
          background: `linear-gradient(135deg, ${alpha(
            theme.palette.background.paper,
            0.9
          )} 0%, ${alpha(theme.palette.background.paper, 0.7)} 100%)`,
          backdropFilter: 'blur(20px)',
          border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
          position: 'relative',
          '&:hover': { boxShadow: '0 25px 50px rgba(0,0,0,0.15)' },
        }}
      >
        <Box
          sx={{
            height: isMobile ? 160 : 200,
            backgroundImage: `linear-gradient(135deg, ${alpha(
              theme.palette.primary.main,
              0.3
            )} 0%, ${alpha(theme.palette.secondary.main, 0.3)} 100%), url(${
              trip.image
            })`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            position: 'relative',
            display: 'flex',
            alignItems: 'flex-end',
            padding: isMobile ? '16px' : '20px',
          }}
        >
          <Box
            sx={{
              position: 'absolute',
              top: 16,
              right: 16,
              display: 'flex',
              gap: 1,
            }}
          >
            <IconButton
              size="small"
              sx={{
                background: alpha(theme.palette.background.paper, 0.9),
                backdropFilter: 'blur(10px)',
                '&:hover': {
                  background: alpha(theme.palette.background.paper, 1),
                },
              }}
            >
              <Favorite fontSize="small" />
            </IconButton>
            <IconButton
              size="small"
              sx={{
                background: alpha(theme.palette.background.paper, 0.9),
                backdropFilter: 'blur(10px)',
                '&:hover': {
                  background: alpha(theme.palette.background.paper, 1),
                },
              }}
            >
              <Share fontSize="small" />
            </IconButton>
          </Box>
          <Box>
            <Typography
              variant={isMobile ? 'h6' : 'h5'}
              sx={{
                color: 'white',
                fontWeight: 800,
                textShadow: '0 2px 10px rgba(0,0,0,0.3)',
              }}
            >
              {trip.title}
            </Typography>
            <Typography
              variant="body2"
              sx={{
                color: alpha('#fff', 0.9),
                fontWeight: 500,
                textShadow: '0 1px 5px rgba(0,0,0,0.3)',
                fontSize: isMobile ? '12px' : '14px',
              }}
            >
              {trip.dates}
            </Typography>
          </Box>
        </Box>
        <CardContent sx={{ padding: isMobile ? '16px' : '20px' }}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              mb: 2,
            }}
          >
            <Chip
              label={trip.status === 'confirmed' ? 'מאושר' : 'בתכנון'}
              color={trip.status === 'confirmed' ? 'success' : 'warning'}
              size="small"
              sx={{ fontWeight: 600, borderRadius: '12px' }}
            />
            <Typography
              variant={isMobile ? 'body1' : 'h6'}
              sx={{ fontWeight: 700, color: theme.palette.primary.main }}
            >
              {trip.budget}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Flight fontSize="small" color="action" />
              <Typography variant="body2" color="text.secondary">
                {trip.days} ימים
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <LocationOn fontSize="small" color="action" />
              <Typography variant="body2" color="text.secondary">
                {trip.destinations.length} יעדים
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const QuickStats = ({ user }: { user: User }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const stats = [
    {
      icon: AttachMoney,
      label: 'הוצאות',
      value: `₪${user.totalSpent.toLocaleString()}`,
      color: theme.palette.success.main,
    },
    {
      icon: LocationOn,
      label: 'מקומות שמורים',
      value: user.savedPlaces,
      color: theme.palette.warning.main,
    },
    {
      icon: Flight,
      label: 'טיולים הושלמו',
      value: user.trips,
      color: theme.palette.info.main,
    },
  ];
  return (
    <Box sx={{ display: 'flex', gap: isMobile ? 1 : 2, mb: 3 }}>
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1, duration: 0.5 }}
            style={{ flex: 1 }}
          >
            <Card
              sx={{
                borderRadius: isMobile ? '16px' : '20px',
                background: `linear-gradient(135deg, ${alpha(
                  stat.color,
                  0.1
                )} 0%, ${alpha(stat.color, 0.05)} 100%)`,
                border: `1px solid ${alpha(stat.color, 0.2)}`,
                padding: isMobile ? '12px' : '16px',
                textAlign: 'center',
                boxShadow: '0 8px 25px rgba(0,0,0,0.08)',
              }}
            >
              <Icon
                sx={{ fontSize: isMobile ? 24 : 32, color: stat.color, mb: 1 }}
              />
              <Typography
                variant={isMobile ? 'body1' : 'h6'}
                sx={{ fontWeight: 700, color: stat.color }}
              >
                {stat.value}
              </Typography>
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{ fontWeight: 500, fontSize: isMobile ? '10px' : '11px' }}
              >
                {stat.label}
              </Typography>
            </Card>
          </motion.div>
        );
      })}
    </Box>
  );
};

const HomePage = ({ trips, user }: { trips: Trip[]; user: User }) => {
  const isMobile = useMediaQuery('(max-width:600px)');
  return (
    <Box sx={{ padding: isMobile ? '16px' : '20px', paddingBottom: '100px' }}>
      <QuickStats user={user} />
      <Box
        sx={{
          mb: 3,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 700 }}>
          הטיולים הקרובים שלך
        </Typography>
        <Chip
          label="הכל"
          variant="outlined"
          size="small"
          sx={{ borderRadius: '12px', fontWeight: 600 }}
        />
      </Box>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {trips.map((trip, index) => (
          <TripCard key={trip.id} trip={trip} index={index} />
        ))}
      </Box>
      <Fab
        color="primary"
        sx={{
          position: 'fixed',
          bottom: 100,
          right: 20,
          background: `linear-gradient(135deg, #1976d2 0%, #dc004e 100%)`,
          boxShadow: '0 8px 25px rgba(25, 118, 210, 0.4)',
          '&:hover': { boxShadow: '0 12px 35px rgba(25, 118, 210, 0.6)' },
        }}
      >
        <Add />
      </Fab>
    </Box>
  );
};

const MapPage = ({ trips }: { trips: Trip[] }) => {
  const isMobile = useMediaQuery('(max-width:600px)');
  const allDestinations = trips.flatMap((trip) => trip.destinations);

  return (
    <Box sx={{ padding: isMobile ? '16px' : '20px', paddingBottom: '100px' }}>
      <Typography variant="h5" sx={{ fontWeight: 800, mb: 3 }}>
        מפת הטיולים שלי
      </Typography>
      <Card sx={{ borderRadius: '20px', overflow: 'hidden', mb: 3 }}>
        <CardContent sx={{ padding: '16px' }}>
          <GoogleMapComponent
            destinations={allDestinations}
            showDirections={false}
          />
        </CardContent>
      </Card>
      <Card sx={{ borderRadius: '20px' }}>
        <CardContent>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
            חפש מקום חדש
          </Typography>
          <PlaceSearch
            onPlaceSelect={(place) => console.log('Selected place:', place)}
            placeholder="חפש יעד לטיול הבא..."
          />
        </CardContent>
      </Card>
    </Box>
  );
};

// Missing BottomNavigation component - adding it here
const BottomNavigation = ({ activeTab, setActiveTab }: { activeTab: string; setActiveTab: (tab: string) => void }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const tabs = [
    { id: 'home', icon: HomeIcon, label: 'בית' },
    { id: 'checklist', icon: CheckCircleOutlineIcon, label: 'רשימה' },
    { id: 'routes', icon: RouteIcon, label: 'מסלולים' },
    { id: 'budget', icon: WalletIcon, label: 'תקציב' },
    { id: 'map', icon: MapIcon, label: 'מפה' },
    { id: 'profile', icon: PersonIcon, label: 'פרופיל' },
  ];

  return (
    <Box
      sx={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: `linear-gradient(135deg, ${alpha(
          theme.palette.background.paper,
          0.95
        )} 0%, ${alpha(theme.palette.background.paper, 0.8)} 100%)`,
        backdropFilter: 'blur(20px)',
        borderTop: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
        padding: isMobile ? '8px 16px' : '12px 20px',
        zIndex: 100,
        boxShadow: '0 -2px 20px rgba(0,0,0,0.05)',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-around',
          alignItems: 'center',
        }}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <IconButton
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              sx={{
                display: 'flex',
                flexDirection: 'column',
                gap: 0.5,
                padding: isMobile ? '8px' : '12px',
                borderRadius: '16px',
                background: isActive
                  ? alpha(theme.palette.primary.main, 0.1)
                  : 'transparent',
                color: isActive
                  ? theme.palette.primary.main
                  : theme.palette.text.secondary,
                '&:hover': {
                  background: alpha(theme.palette.primary.main, 0.05),
                },
              }}
            >
              <Icon fontSize={isMobile ? 'small' : 'medium'} />
              <Typography
                variant="caption"
                sx={{
                  fontSize: isMobile ? '10px' : '11px',
                  fontWeight: isActive ? 600 : 400,
                }}
              >
                {tab.label}
              </Typography>
            </IconButton>
          );
        })}
      </Box>
    </Box>
  );
};

// =================================================================
// רכיב ראשי - App
// =================================================================
function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [tripsData, setTripsData] = useState<Trip[]>([]);
  const [userData, setUserData] = useState<User | null>(null);
  const theme = useTheme();

  useEffect(() => {
    const unsubscribeTrips = onSnapshot(collection(db, 'trips'), (snapshot) => {
      const fetchedTrips = snapshot.docs.map(
        (doc) => ({ ...doc.data(), id: doc.id } as Trip)
      );
      setTripsData(fetchedTrips);
    });
    const unsubscribeUser = onSnapshot(doc(db, 'users', 'mainUser'), (doc) => {
      if (doc.exists()) {
        setUserData(doc.data() as User);
      } else {
        console.log('User not found!');
      }
    });
    return () => {
      unsubscribeTrips();
      unsubscribeUser();
    };
  }, []);

  const renderContent = () => {
    if (!userData || tripsData.length === 0) {
      return (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
          <Typography>טוען נתונים...</Typography>
        </Box>
      );
    }

    switch (activeTab) {
      case 'home':
        return <HomePage trips={tripsData} user={userData} />;
      case 'checklist':
        return <Checklist tripId={tripsData[0].id.toString()} />;
      case 'routes':
        return <RouteManager trip={tripsData[0]} />;
      case 'budget':
        return <BudgetTracker trip={tripsData[0]} />;
      case 'profile':
        return <UserProfile />; // TODO: Pass user and trips props
      case 'map':
        return <MapPage trips={tripsData} />;
      default:
        return <HomePage trips={tripsData} user={userData} />;
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: `linear-gradient(135deg, ${alpha(
          theme.palette.background.default,
          1
        )} 0%, ${alpha(theme.palette.grey[50], 1)} 100%)`,
        position: 'relative',
        overflowX: 'hidden',
      }}
    >
      {userData && <Header user={userData} />}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
        >
          {renderContent()}
        </motion.div>
      </AnimatePresence>
      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </Box>
  );
}

export default App;