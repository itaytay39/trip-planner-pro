// src/components/RouteManager.tsx

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Chip,
  Button
} from '@mui/material';
import { 
  DragIndicator,
  Delete,
  Edit,
  Route,
  LocationOn,
  AccessTime
} from '@mui/icons-material';
import GoogleMapComponent from './GoogleMap';
import PlaceSearch from './PlaceSearch';
import { Destination, Trip } from '../types';
import { db } from '../firebase';
import { doc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import toast from 'react-hot-toast';

interface RouteManagerProps {
  trip: Trip;
}

const RouteManager: React.FC<RouteManagerProps> = ({ trip }) => {
  // המצב הפנימי מתאתחל מה-trip שהתקבל
  const [destinations, setDestinations] = useState<Destination[]>(trip.destinations);
  const [showDirections, setShowDirections] = useState(true);

  // עדכון המצב הפנימי אם ה-prop של הטיול משתנה
  useEffect(() => {
    setDestinations(trip.destinations);
  }, [trip]);

  const handleAddDestination = async (newDestination: Destination) => {
    const tripRef = doc(db, 'trips', trip.id.toString()); // שימוש ב-ID של הטיול
    try {
      await updateDoc(tripRef, {
        destinations: arrayUnion(newDestination)
      });
      toast.success('יעד חדש נוסף למסלול!');
    } catch (e) {
      console.error("Error adding destination: ", e);
      toast.error('שגיאה בהוספת היעד');
    }
  };

  const handleDeleteDestination = async (destinationToDelete: Destination) => {
    const tripRef = doc(db, 'trips', trip.id.toString());
    try {
      await updateDoc(tripRef, {
        destinations: arrayRemove(destinationToDelete)
      });
      toast.success('היעד נמחק מהמסלול!');
    } catch (e) {
      console.error("Error deleting destination: ", e);
      toast.error('שגיאה במחיקת היעד');
    }
  };

  const getDestinationIcon = (type: Destination['type']) => {
    const iconMap = { hotel: '🏨', restaurant: '🍽️', attraction: '🎯', transport: '🚌' };
    return iconMap[type] || '📍';
  };

  const getTypeLabel = (type: Destination['type']) => {
    const labelMap = { hotel: 'מלון', restaurant: 'מסעדה', attraction: 'אטרקציה', transport: 'תחבורה' };
    return labelMap[type] || 'אחר';
  };
  
  const getTypeColor = (type: Destination['type']) => {
    const colorMap = { hotel: 'primary', restaurant: 'warning', attraction: 'success', transport: 'secondary' };
    return colorMap[type] as 'primary' | 'warning' | 'success' | 'secondary' | 'default' || 'default';
  };

  const totalEstimatedCost = destinations.reduce((sum, dest) => sum + (dest.estimatedCost || 0), 0);

  return (
    <Box sx={{ padding: '20px', paddingBottom: '100px' }}>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 800, mb: 1 }}>
          מסלול: {trip.title}
        </Typography>
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
          <Chip icon={<LocationOn />} label={`${destinations.length} יעדים`} size="small" />
          <Chip icon={<AccessTime />} label={`${trip.days} ימים`} size="small" />
          {totalEstimatedCost > 0 && <Chip label={`₪${totalEstimatedCost.toLocaleString()}`} size="small" color="primary" />}
        </Box>
      </Box>

      <Card sx={{ borderRadius: '20px', mb: 3, overflow: 'hidden' }}>
        <GoogleMapComponent destinations={destinations} showDirections={showDirections} />
      </Card>

      <Card sx={{ borderRadius: '20px', mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>הוסף יעד חדש</Typography>
          <PlaceSearch onPlaceSelect={handleAddDestination} placeholder="חפש מקום להוספה למסלול..."/>
        </CardContent>
      </Card>

      <Card sx={{ borderRadius: '20px' }}>
        <CardContent>
           <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>יעדים במסלול</Typography>
          <List>
            {destinations.map((destination, index) => (
              <ListItem key={destination.id} sx={{ borderRadius: '12px', mb: 1, backgroundColor: 'grey.50', border: '1px solid', borderColor: 'divider' }}>
                <ListItemIcon>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 700, minWidth: '20px' }}>{index + 1}</Typography>
                    <Typography sx={{ fontSize: '20px' }}>{getDestinationIcon(destination.type)}</Typography>
                  </Box>
                </ListItemIcon>
                <ListItemText
                  primary={<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><Typography variant="subtitle1" sx={{ fontWeight: 600 }}>{destination.name}</Typography><Chip label={getTypeLabel(destination.type)} size="small" color={getTypeColor(destination.type)}/></Box>}
                  secondary={destination.notes}
                />
                <ListItemSecondaryAction>
                    <IconButton size="small" color="error" onClick={() => handleDeleteDestination(destination)}>
                      <Delete />
                    </IconButton>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        </CardContent>
      </Card>
    </Box>
  );
};

export default RouteManager;