import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent,
  Avatar,
  Chip,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Switch,
  FormControlLabel,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Divider,
  LinearProgress
} from '@mui/material';
import { 
  Person,
  Flight,
  LocationOn,
  AttachMoney,
  Settings,
  Notifications,
  Language,
  Security,
  Help,
  Logout,
  Edit,
  Star,
  TrendingUp,
  EmojiEvents
} from '@mui/icons-material';
import { userData, tripsData, budgetData } from '../data/mockData';

const UserProfile: React.FC = () => {
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [profileData, setProfileData] = useState(userData);

  const totalSpent = budgetData.reduce((sum, item) => sum + item.amount, 0);
  const completedTrips = tripsData.filter(trip => trip.status === 'confirmed').length;
  const savedPlaces = userData.savedPlaces;

  // חישוב רמת המשתמש
  const getLevel = (trips: number) => {
    if (trips >= 20) return { name: 'מטייל מקצועי', color: '#FFD700', progress: 100 };
    if (trips >= 10) return { name: 'מטייל מנוסה', color: '#FF6B35', progress: (trips / 20) * 100 };
    if (trips >= 5) return { name: 'מטייל פעיל', color: '#4ECDC4', progress: (trips / 10) * 100 };
    return { name: 'מטייל מתחיל', color: '#45B7D1', progress: (trips / 5) * 100 };
  };

  const userLevel = getLevel(profileData.trips);

  const achievements = [
    { id: 1, name: 'מטייל ראשון', description: 'השלמת הטיול הראשון', earned: true },
    { id: 2, name: 'חוסך תקציב', description: 'חיסכון של 20% מהתקציב', earned: true },
    { id: 3, name: 'גלובטרוטר', description: 'ביקור ב-10 מדינות', earned: false },
    { id: 4, name: 'מתכנן מקצועי', description: 'תכנון 5 טיולים', earned: true },
  ];

  const stats = [
    { label: 'טיולים שהושלמו', value: profileData.trips, icon: Flight, color: '#1976d2' },
    { label: 'מקומות שמורים', value: savedPlaces, icon: LocationOn, color: '#4caf50' },
    { label: 'סה"כ הוצאות', value: `₪${totalSpent.toLocaleString()}`, icon: AttachMoney, color: '#ff9800' },
  ];

  return (
    <Box sx={{ padding: '20px', paddingBottom: '100px' }}>
      {/* פרופיל משתמש */}
      <Card sx={{ borderRadius: '24px', mb: 3, background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <CardContent sx={{ color: 'white', textAlign: 'center', padding: '32px 24px' }}>
          <Avatar
            src={profileData.avatar}
            sx={{ 
              width: 100, 
              height: 100, 
              margin: '0 auto 16px',
              border: '4px solid rgba(255,255,255,0.3)'
            }}
          />
          <Typography variant="h4" sx={{ fontWeight: 800, mb: 1 }}>
            {profileData.name}
          </Typography>
          <Chip 
            label={userLevel.name}
            sx={{ 
              backgroundColor: userLevel.color,
              color: 'white',
              fontWeight: 600,
              mb: 2
            }}
          />
          <Box sx={{ mt: 2 }}>
            <Typography variant="body2" sx={{ opacity: 0.9, mb: 1 }}>
              התקדמות לרמה הבאה
            </Typography>
            <LinearProgress 
              variant="determinate" 
              value={userLevel.progress}
              sx={{ 
                height: 8, 
                borderRadius: 4,
                backgroundColor: 'rgba(255,255,255,0.3)',
                '& .MuiLinearProgress-bar': {
                  backgroundColor: userLevel.color
                }
              }}
            />
          </Box>
          <Button
            startIcon={<Edit />}
            variant="outlined"
            onClick={() => setOpenEditDialog(true)}
            sx={{ 
              mt: 2,
              borderColor: 'rgba(255,255,255,0.5)',
              color: 'white',
              '&:hover': {
                borderColor: 'white',
                backgroundColor: 'rgba(255,255,255,0.1)'
              }
            }}
          >
            עריכת פרופיל
          </Button>
        </CardContent>
      </Card>

      {/* סטטיסטיקות */}
      <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
        הסטטיסטיקות שלי
      </Typography>
      
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: 2, mb: 3 }}>
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} sx={{ borderRadius: '16px', textAlign: 'center' }}>
              <CardContent sx={{ padding: '20px !important' }}>
                <Icon sx={{ fontSize: 32, color: stat.color, mb: 1 }} />
                <Typography variant="h6" sx={{ fontWeight: 700, color: stat.color }}>
                  {stat.value}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {stat.label}
                </Typography>
              </CardContent>
            </Card>
          );
        })}
      </Box>

      {/* הישגים */}
      <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
        הישגים
      </Typography>
      
      <Card sx={{ borderRadius: '20px', mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2 }}>
            {achievements.map((achievement) => (
              <Box 
                key={achievement.id}
                sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 2,
                  padding: '12px',
                  borderRadius: '12px',
                  backgroundColor: achievement.earned ? 'success.light' : 'grey.100',
                  opacity: achievement.earned ? 1 : 0.6
                }}
              >
                <EmojiEvents 
                  sx={{ 
                    color: achievement.earned ? 'success.main' : 'grey.400',
                    fontSize: 32
                  }} 
                />
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    {achievement.name}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {achievement.description}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>

      {/* הגדרות */}
      <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
        הגדרות
      </Typography>
      
      <Card sx={{ borderRadius: '20px' }}>
        <List>
          <ListItem>
            <ListItemIcon>
              <Notifications />
            </ListItemIcon>
            <ListItemText primary="התראות" secondary="קבל עדכונים על הטיולים שלך" />
            <Switch
              checked={notifications}
              onChange={(e) => setNotifications(e.target.checked)}
            />
          </ListItem>
          
          <Divider />
          
          <ListItem button>
            <ListItemIcon>
              <Language />
            </ListItemIcon>
            <ListItemText primary="שפה" secondary="עברית" />
          </ListItem>
          
          <Divider />
          
          <ListItem button>
            <ListItemIcon>
              <Security />
            </ListItemIcon>
            <ListItemText primary="פרטיות ואבטחה" secondary="נהל את הגדרות הפרטיות" />
          </ListItem>
          
          <Divider />
          
          <ListItem button>
            <ListItemIcon>
              <Help />
            </ListItemIcon>
            <ListItemText primary="עזרה ותמיכה" secondary="מרכז העזרה ויצירת קשר" />
          </ListItem>
          
          <Divider />
          
          <ListItem button sx={{ color: 'error.main' }}>
            <ListItemIcon>
              <Logout sx={{ color: 'error.main' }} />
            </ListItemIcon>
            <ListItemText primary="התנתקות" />
          </ListItem>
        </List>
      </Card>

      {/* דיאלוג עריכת פרופיל */}
      <Dialog open={openEditDialog} onClose={() => setOpenEditDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>עריכת פרופיל</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
            <TextField
              label="שם מלא"
              value={profileData.name}
              onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
              fullWidth
            />
            <TextField
              label="כתובת אימייל"
              type="email"
              defaultValue="yossi@example.com"
              fullWidth
            />
            <TextField
              label="טלפון"
              defaultValue="050-1234567"
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenEditDialog(false)}>
            ביטול
          </Button>
          <Button variant="contained" onClick={() => setOpenEditDialog(false)}>
            שמור
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default UserProfile;