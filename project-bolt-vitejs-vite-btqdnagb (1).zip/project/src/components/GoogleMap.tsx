import React, { useState, useCallback, useRef } from 'react';
import { GoogleMap, LoadScript, Marker, InfoWindow, DirectionsRenderer } from '@react-google-maps/api';
import { Box, Typography, Card, CardContent, Chip, IconButton } from '@mui/material';
import { Hotel, Restaurant, Attractions, DirectionsWalk } from '@mui/icons-material';
import type { Destination } from '../types';

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

const mapContainerStyle = {
  width: '100%',
  height: '400px',
  borderRadius: '16px'
};

const defaultCenter = {
  lat: 40.7128,
  lng: -74.0060 // ניו יורק כברירת מחדל
};

const libraries: ("places" | "geometry" | "drawing" | "visualization")[] = ["places"];

interface GoogleMapComponentProps {
  destinations: Destination[];
  onDestinationClick?: (destination: Destination) => void;
  showDirections?: boolean;
}

const GoogleMapComponent: React.FC<GoogleMapComponentProps> = ({ 
  destinations, 
  onDestinationClick,
  showDirections = false 
}) => {
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);

  const onMapLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    
    // התאמת המפה להציג את כל הנקודות
    if (destinations.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      destinations.forEach(dest => {
        bounds.extend({ lat: dest.lat, lng: dest.lng });
      });
      map.fitBounds(bounds);
    }
  }, [destinations]);

  const calculateRoute = useCallback(() => {
    if (destinations.length < 2 || !mapRef.current) return;

    const directionsService = new google.maps.DirectionsService();
    const origin = destinations[0];
    const destination = destinations[destinations.length - 1];
    const waypoints = destinations.slice(1, -1).map(dest => ({
      location: { lat: dest.lat, lng: dest.lng },
      stopover: true
    }));

    directionsService.route(
      {
        origin: { lat: origin.lat, lng: origin.lng },
        destination: { lat: destination.lat, lng: destination.lng },
        waypoints,
        travelMode: google.maps.TravelMode.WALKING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          setDirections(result);
        }
      }
    );
  }, [destinations]);

  React.useEffect(() => {
    if (showDirections && destinations.length > 1) {
      calculateRoute();
    }
  }, [showDirections, destinations, calculateRoute]);

  const getMarkerIcon = (type: Destination['type']) => {
    const iconMap = {
      hotel: '🏨',
      restaurant: '🍽️',
      attraction: '🎯',
      transport: '🚌'
    };
    return iconMap[type] || '📍';
  };

  const getTypeColor = (type: Destination['type']) => {
    const colorMap = {
      hotel: '#2196F3',
      restaurant: '#FF9800',
      attraction: '#4CAF50',
      transport: '#9C27B0'
    };
    return colorMap[type] || '#757575';
  };

  return (
    <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY} libraries={libraries}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={destinations.length > 0 ? { lat: destinations[0].lat, lng: destinations[0].lng } : defaultCenter}
        zoom={12}
        onLoad={onMapLoad}
        options={{
          styles: [
            {
              featureType: "poi",
              elementType: "labels",
              stylers: [{ visibility: "off" }]
            }
          ],
          disableDefaultUI: false,
          zoomControl: true,
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: true,
        }}
      >
        {destinations.map((destination) => (
          <Marker
            key={destination.id}
            position={{ lat: destination.lat, lng: destination.lng }}
            onClick={() => setSelectedDestination(destination)}
            icon={{
              url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
                <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="20" cy="20" r="18" fill="${getTypeColor(destination.type)}" stroke="white" stroke-width="3"/>
                  <text x="20" y="26" text-anchor="middle" font-size="16" fill="white">${getMarkerIcon(destination.type)}</text>
                </svg>
              `)}`,
              scaledSize: new google.maps.Size(40, 40),
            }}
          />
        ))}

        {selectedDestination && (
          <InfoWindow
            position={{ lat: selectedDestination.lat, lng: selectedDestination.lng }}
            onCloseClick={() => setSelectedDestination(null)}
          >
            <Card sx={{ minWidth: 200, boxShadow: 'none' }}>
              <CardContent sx={{ padding: '12px !important' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  <Chip 
                    size="small" 
                    label={selectedDestination.type === 'hotel' ? 'מלון' : 
                          selectedDestination.type === 'restaurant' ? 'מסעדה' :
                          selectedDestination.type === 'attraction' ? 'אטרקציה' : 'תחבורה'}
                    sx={{ backgroundColor: getTypeColor(selectedDestination.type), color: 'white' }}
                  />
                </Box>
                <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                  {selectedDestination.name}
                </Typography>
                {selectedDestination.estimatedCost && (
                  <Typography variant="body2" color="primary" sx={{ fontWeight: 600 }}>
                    ₪{selectedDestination.estimatedCost}
                  </Typography>
                )}
                {selectedDestination.notes && (
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    {selectedDestination.notes}
                  </Typography>
                )}
              </CardContent>
            </Card>
          </InfoWindow>
        )}

        {showDirections && directions && (
          <DirectionsRenderer
            directions={directions}
            options={{
              polylineOptions: {
                strokeColor: '#1976d2',
                strokeWeight: 4,
                strokeOpacity: 0.8,
              },
              suppressMarkers: true,
            }}
          />
        )}
      </GoogleMap>
    </LoadScript>
  );
};

export default GoogleMapComponent;