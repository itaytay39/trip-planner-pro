import React, { useState, useRef } from 'react';
import { LoadScript, Autocomplete } from '@react-google-maps/api';
import { TextField, Box, IconButton, Paper, List, ListItem, ListItemText, ListItemIcon } from '@mui/material';
import { Search, LocationOn, Add } from '@mui/icons-material';
import type { Destination } from '../types';

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
const libraries: ("places" | "geometry" | "drawing" | "visualization")[] = ["places"];

interface PlaceSearchProps {
  onPlaceSelect: (place: Destination) => void;
  placeholder?: string;
}

const PlaceSearch: React.FC<PlaceSearchProps> = ({ onPlaceSelect, placeholder = "חפש מקום..." }) => {
  const [autocomplete, setAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const onLoad = (autocompleteInstance: google.maps.places.Autocomplete) => {
    setAutocomplete(autocompleteInstance);
  };

  const onPlaceChanged = () => {
    if (autocomplete) {
      const place = autocomplete.getPlace();
      
      if (place.geometry && place.geometry.location) {
        const newDestination: Destination = {
          id: Date.now().toString(),
          name: place.name || place.formatted_address || 'מקום לא ידוע',
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng(),
          type: determineType(place.types || []),
          notes: place.formatted_address || ''
        };
        
        onPlaceSelect(newDestination);
        setSearchValue('');
        if (inputRef.current) {
          inputRef.current.value = '';
        }
      }
    }
  };

  const determineType = (types: string[]): Destination['type'] => {
    if (types.includes('lodging')) return 'hotel';
    if (types.includes('restaurant') || types.includes('food')) return 'restaurant';
    if (types.includes('transit_station') || types.includes('bus_station')) return 'transport';
    return 'attraction';
  };

  return (
    <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY} libraries={libraries}>
      <Box sx={{ position: 'relative', width: '100%' }}>
        <Autocomplete onLoad={onLoad} onPlaceChanged={onPlaceChanged}>
          <TextField
            ref={inputRef}
            fullWidth
            placeholder={placeholder}
            variant="outlined"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            InputProps={{
              startAdornment: <Search sx={{ color: 'text.secondary', mr: 1 }} />,
              endAdornment: (
                <IconButton size="small" color="primary">
                  <Add />
                </IconButton>
              ),
              sx: {
                borderRadius: '16px',
                backgroundColor: 'background.paper',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'divider',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.main',
                },
              }
            }}
          />
        </Autocomplete>
      </Box>
    </LoadScript>
  );
};

export default PlaceSearch;