export interface Trip {
  id: number;
  title: string;
  dates: string;
  image: string;
  budget: string;
  days: number;
  status: 'confirmed' | 'planning';
  destinations: Destination[];
}

export interface Destination {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'hotel' | 'restaurant' | 'attraction' | 'transport';
  estimatedCost?: number;
  notes?: string;
}

export interface BudgetItem {
  id: string;
  category: 'transport' | 'accommodation' | 'food' | 'activities' | 'shopping' | 'other';
  name: string;
  amount: number;
  date: string;
  tripId?: number;
}

export interface User {
  name: string;
  avatar: string;
  level: string;
  trips: number;
  totalSpent: number;
  savedPlaces: number;
}
// src/types/index.ts

// הוסף את הממשק הבא מתחת לשאר הממשקים
export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}